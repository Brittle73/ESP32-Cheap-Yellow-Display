# EVA Countdown for CYD (ESP32-2432S028)

This working copy adapts EVA Countdown for the board shown in the supplied photo: the ESP32-2432S028 CYD, based on a classic ESP32 module, 320×240 ILI9341 TFT, XPT2046 touch panel, and CH340 USB-to-serial bridge. The original Waveshare ESP32-S3-RLCD-4.2 source is retained in `README_UPSTREAM.md`; original licenses and notices remain included.

## Build

Use an ESP-IDF PowerShell terminal (the checked local toolchain is ESP-IDF 5.5.6):

```powershell
idf.py set-target esp32
idf.py build
```

The build does not require external component downloads. The app's LCD driver uses the CYD's SPI pins at 26 MHz, with the TFT rotated 180 degrees for the photographed unit; the serial console and clock-setting commands use UART0 at 115200 baud through the CH340.

## Recover and flash

Close serial monitors first. Check the chip and flash size, then read a full flash backup before replacing firmware. This board family normally has 4 MB flash:

```powershell
esptool.py --port COM5 flash_id
esptool.py --chip esp32 --port COM5 read_flash 0 0x400000 cyd-before-eva.bin
idf.py -p COM5 flash monitor
```

Keep `cyd-before-eva.bin` somewhere safe; a flash dump can include device data. Do not use `erase-flash` for routine updates. If automatic bootloader entry fails, hold BOOT while starting the flash command, then release it when connecting begins.

## Controls

- Tap one of the three bottom screen zones to select Countdown, Clock, or Pomodoro.
- Tap the main area to start/pause Countdown or Pomodoro; hold it for 0.8 seconds to reset.
- The physical BOOT button cycles modes; holding it in Countdown toggles Normal/Racing.
- Pomodoro continues in the background when you switch modes.
- There is no RTC on this CYD board. The Clock mode needs a USB time sync and loses its time on reset:

```powershell
python -m pip install -r tools/requirements.txt
python tools/set_clock.py --port COM5
```

The ESP32-D0WD-V3 on COM5 was flashed successfully. Its 0x10000 app partition was read back and SHA-256 matched the built image. The UART startup log is in `firmware/startup-log-COM5.txt`. Startup completes without errors after the 180-degree LCD and touch orientation correction.

A CYD-specific screen preview is in `preview/cyd-countdown.png`. It is rendered from the project's own monochrome assets and fitted to 320×240. Touch calibration and physical display behavior still need confirmation on the device.
