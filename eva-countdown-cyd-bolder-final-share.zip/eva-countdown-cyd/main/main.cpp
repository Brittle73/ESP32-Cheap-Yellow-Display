// SPDX-License-Identifier: Apache-2.0
#include "board.h"
#include "display.h"
#include "app.h"
#include "render.h"
#include "driver/gpio.h"
#include "driver/uart.h"
#include "esp_app_desc.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <cstdio>
#include <cstring>
#include <ctime>
#include <sys/time.h>

namespace {
constexpr const char *tag = "eva";
void reply(const char *line) { uart_write_bytes(UART_NUM_0, line, std::strlen(line)); }
void command(const char *line, eva::App &app) {
    if (std::strcmp(line, "INFO") == 0) {
        char b[120];
        std::snprintf(b, sizeof(b), "EVA %s BOARD=ESP32-2432S028 POWER=USB-SERIAL\n",
                      esp_app_get_description()->version);
        reply(b);
        return;
    }
    if (std::strcmp(line, "TIME?") == 0) {
        timeval now{};
        gettimeofday(&now, nullptr);
        const std::time_t seconds = now.tv_sec;
        std::tm local{};
        if (seconds < 946684800 || localtime_r(&seconds, &local) == nullptr) {
            reply("ERR CLOCK_UNSET_UNTIL_USB_SYNC\n");
            return;
        }
        char b[80];
        std::snprintf(b, sizeof(b), "TIME %04d-%02d-%02dT%02d:%02d:%02d\n",
                      local.tm_year + 1900, local.tm_mon + 1, local.tm_mday,
                      local.tm_hour, local.tm_min, local.tm_sec);
        reply(b);
        return;
    }
    eva::DateTime time;
    if (!eva::parse_time(line, time)) {
        reply("ERR EXPECTED_TIME_YYYY-MM-DDTHH:MM:SS\n");
        return;
    }
    std::tm value{};
    value.tm_year = time.year - 1900;
    value.tm_mon = time.month - 1;
    value.tm_mday = time.day;
    value.tm_hour = time.hour;
    value.tm_min = time.minute;
    value.tm_sec = time.second;
    const std::time_t seconds = std::mktime(&value);
    timeval clock{seconds, 0};
    if (seconds < 0 || settimeofday(&clock, nullptr) != 0) {
        reply("ERR SYSTEM_CLOCK_SET_FAILED\n");
        return;
    }
    char b[80];
    std::snprintf(b, sizeof(b), "OK TIME %04d-%02d-%02dT%02d:%02d:%02d\n",
                  time.year, time.month, time.day, time.hour, time.minute, time.second);
    reply(b);
}
} // namespace

extern "C" void app_main(void) {
    gpio_config_t button{};
    button.pin_bit_mask = 1ULL << board::boot;
    button.mode = GPIO_MODE_INPUT;
    button.pull_up_en = GPIO_PULLUP_ENABLE;
    ESP_ERROR_CHECK(gpio_config(&button));
    ESP_ERROR_CHECK(uart_driver_install(UART_NUM_0, 1024, 1024, 0, nullptr, 0));
    static eva::App app;
    ESP_LOGI(tag, "v%s: CYD ILI9341; touch bottom markers to select mode, tap screen to start/pause, hold to reset",
             esp_app_get_description()->version);
    ESP_LOGI(tag, "USB UART console on CH340; clock is volatile and can be set with tools/set_clock.py");
    display_init();
    static eva::Frame frame, previous;
    Button boot;
    eva::LineReader lines;
    bool first = true, was_touched = false, touch_is_mode = false;
    int64_t touch_started = 0, last_frame = -board::frame_interval_us;
    for (;;) {
        const auto now = esp_timer_get_time();
        int tx = 0, ty = 0;
        const bool touched = display_touch(tx, ty);
        if (touched && !was_touched) {
            touch_started = now;
            touch_is_mode = ty >= 210;
        } else if (!touched && was_touched) {
            if (touch_is_mode) {
                app.mode = tx < board::lcd_width / 3 ? eva::Mode::Countdown
                         : tx < 2 * board::lcd_width / 3 ? eva::Mode::Clock : eva::Mode::Pomodoro;
            } else if (now - touch_started >= 800000) {
                app.input(Button::Hold, Button::None, now);
            } else {
                app.input(Button::Click, Button::None, now);
            }
        }
        was_touched = touched;
        app.input(Button::None, boot.update(gpio_get_level(board::boot) == 0, now), now);
        app.tick(now);
        char input[64];
        const int count = uart_read_bytes(UART_NUM_0, input, sizeof(input), 0);
        for (int i = 0; i < count; ++i)
            if (lines.push(input[i]))
                command(lines.line(), app);
        if (now - last_frame >= board::frame_interval_us) {
            eva::render(frame, app, now);
            if (first || std::memcmp(frame.data, previous.data, eva::bytes) != 0) {
                display_frame(frame);
                std::memcpy(previous.data, frame.data, eva::bytes);
                first = false;
            }
            last_frame = now;
        }
        vTaskDelay(pdMS_TO_TICKS(5));
    }
}
