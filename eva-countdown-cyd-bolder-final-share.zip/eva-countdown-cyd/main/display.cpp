// SPDX-License-Identifier: Apache-2.0
#include "display.h"
#include "board.h"
#include "driver/gpio.h"
#include "driver/spi_master.h"
#include "esp_check.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include <algorithm>

namespace {
spi_device_handle_t lcd_spi;
spi_device_handle_t touch_spi;
uint16_t line[board::lcd_width];
void send(bool is_data, const void *buffer, size_t bytes) {
    ESP_ERROR_CHECK(gpio_set_level(board::dc, is_data));
    spi_transaction_t tx{};
    tx.length = bytes * 8;
    tx.tx_buffer = buffer;
    ESP_ERROR_CHECK(spi_device_polling_transmit(lcd_spi, &tx));
}
void command(uint8_t value) { send(false, &value, 1); }
void data(uint8_t value) { send(true, &value, 1); }
uint16_t touch_axis(uint8_t command_byte) {
    uint8_t tx_data[3]{command_byte, 0, 0}, rx_data[3]{};
    spi_transaction_t tx{};
    tx.length = 24;
    tx.tx_buffer = tx_data;
    tx.rx_buffer = rx_data;
    ESP_ERROR_CHECK(spi_device_polling_transmit(touch_spi, &tx));
    return uint16_t(((uint16_t(rx_data[1]) << 8) | rx_data[2]) >> 3) & 0x0fff;
}
} // namespace

void display_init() {
    gpio_config_t gpio{};
    gpio.pin_bit_mask = (1ULL << board::dc) | (1ULL << board::backlight);
    gpio.mode = GPIO_MODE_OUTPUT;
    ESP_ERROR_CHECK(gpio_config(&gpio));
    ESP_ERROR_CHECK(gpio_set_level(board::backlight, 1));

    spi_bus_config_t bus{};
    bus.mosi_io_num = board::mosi;
    bus.miso_io_num = board::miso;
    bus.sclk_io_num = board::clock;
    bus.quadwp_io_num = -1;
    bus.quadhd_io_num = -1;
    bus.max_transfer_sz = board::lcd_width * 2;
    ESP_ERROR_CHECK(spi_bus_initialize(SPI3_HOST, &bus, SPI_DMA_CH_AUTO));
    spi_device_interface_config_t device{};
    device.clock_speed_hz = board::spi_hz;
    device.mode = 0;
    device.spics_io_num = board::cs;
    device.queue_size = 1;
    ESP_ERROR_CHECK(spi_bus_add_device(SPI3_HOST, &device, &lcd_spi));

    gpio_config_t irq{};
    irq.pin_bit_mask = 1ULL << board::touch_irq;
    irq.mode = GPIO_MODE_INPUT;
    irq.pull_up_en = GPIO_PULLUP_DISABLE; // GPIO36 is input-only on the classic ESP32.
    ESP_ERROR_CHECK(gpio_config(&irq));
    spi_bus_config_t touch_bus{};
    touch_bus.mosi_io_num = board::touch_mosi;
    touch_bus.miso_io_num = board::touch_miso;
    touch_bus.sclk_io_num = board::touch_clock;
    touch_bus.quadwp_io_num = -1;
    touch_bus.quadhd_io_num = -1;
    touch_bus.max_transfer_sz = 4;
    ESP_ERROR_CHECK(spi_bus_initialize(SPI2_HOST, &touch_bus, SPI_DMA_CH_AUTO));
    spi_device_interface_config_t touch_device{};
    touch_device.clock_speed_hz = 2500000;
    touch_device.mode = 0;
    touch_device.spics_io_num = board::touch_cs;
    touch_device.queue_size = 1;
    ESP_ERROR_CHECK(spi_bus_add_device(SPI2_HOST, &touch_device, &touch_spi));

    command(0x01); // Software reset.
    vTaskDelay(pdMS_TO_TICKS(150));
    command(0x11); // Sleep out.
    vTaskDelay(pdMS_TO_TICKS(120));
    command(0x3A); data(0x55); // RGB565.
    command(0x36); data(0xe8); // Landscape rotated 180 degrees, BGR panel order.
    command(0x21); // Inversion on.
    command(0x29); // Display on.
    vTaskDelay(pdMS_TO_TICKS(20));
}

void display_frame(const eva::Frame &frame) {
    command(0x2A); data(0); data(0); data(1); data(63); // 0..319
    command(0x2B); data(0); data(0); data(0); data(239); // 0..239
    command(0x2C);
    for (int y = 0; y < board::lcd_height; ++y) {
        const int source_y = y * eva::height / board::lcd_height;
        for (int x = 0; x < board::lcd_width; ++x) {
            const int source_x = (board::lcd_width - 1 - x) * eva::width / board::lcd_width;
            const uint16_t color = frame.pixel(source_x, source_y) ? 0xffff : 0x0000;
            line[x] = (color >> 8) | (color << 8); // RGB565 MSB first.
        }
        send(true, line, sizeof(line));
    }
}

bool display_touch(int &x, int &y) {
    if (gpio_get_level(board::touch_irq) != 0)
        return false;
    const uint16_t raw_x = touch_axis(0xd0);
    const uint16_t raw_y = touch_axis(0x90);
    const int scaled_x = (int(raw_x) - 280) * board::lcd_width / (3860 - 280);
    const int scaled_y = (int(raw_y) - 340) * board::lcd_height / (3860 - 340);
    x = std::clamp(board::lcd_width - 1 - scaled_x, 0, board::lcd_width - 1);
    y = std::clamp(board::lcd_height - 1 - scaled_y, 0, board::lcd_height - 1);
    return true;
}
