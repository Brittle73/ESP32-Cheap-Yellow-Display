// SPDX-License-Identifier: Apache-2.0
#pragma once
#include <cstdint>
#include "driver/gpio.h"
namespace board {
// Sunton ESP32-2432S028 CYD: classic ESP32, ILI9341 TFT and XPT2046 touch.
constexpr gpio_num_t boot = GPIO_NUM_0;
constexpr gpio_num_t mosi = GPIO_NUM_13, clock = GPIO_NUM_14, miso = GPIO_NUM_12;
constexpr gpio_num_t dc = GPIO_NUM_2, cs = GPIO_NUM_15, backlight = GPIO_NUM_21;
constexpr gpio_num_t touch_mosi = GPIO_NUM_32, touch_clock = GPIO_NUM_25;
constexpr gpio_num_t touch_miso = GPIO_NUM_39, touch_cs = GPIO_NUM_33, touch_irq = GPIO_NUM_36;
constexpr int spi_hz = 26000000;
constexpr int64_t frame_interval_us = 40000;
constexpr int lcd_width = 320, lcd_height = 240;
} // namespace board
