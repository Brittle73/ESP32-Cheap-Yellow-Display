// SPDX-License-Identifier: Apache-2.0
#pragma once
#include "graphics.h"
void display_init();
void display_frame(const eva::Frame &frame);
bool display_touch(int &x, int &y);
